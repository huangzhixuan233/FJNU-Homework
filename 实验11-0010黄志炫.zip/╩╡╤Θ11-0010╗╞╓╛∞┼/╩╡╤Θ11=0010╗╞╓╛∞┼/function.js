var products = [{name:"iPhone 6 32GB 金色 移动联通电信4G",price:2756.00,pic:"mobile_0.jpg"},
                {name:"OPPO R11 全网通 黑色版",price:2999.00,pic: "mobile_1.jpg"},
                {name:"Apple iPhone 6s Plus 32GB 金色 移动联通电信4G手机",price:3898.00,pic: "mobile_2.jpg"},
                {name:"小米 红米手机4X 全网通版 2GB内存 16GB 香槟金",price:699.00,pic: "mobile_3.jpg"},
                {name:"小米 红米手机4X 全网通版 2GB内存 16GB 玫瑰金",price:599.00,pic: "mobile_4.jpg"},
                {name:"小米 红米手机4X 全网通版 2GB内存 16GB 樱花金",price:699.00,pic: "mobile_5.jpg"}];
var isSlected = [0,0,0,0,0,0];
var cart = {products:[],count:0,total:0};
var product = ["iPhone 6 32GB 金色 移动联通电信4G", 
               "OPPO R11 全网通 黑色版", 
               "Apple iPhone 6s Plus 32GB 金色 移动联通电信4G手机", 
               "小米 红米手机4X 全网通版 2GB内存 16GB 香槟金",
               "小米 红米手机4A 全网通版 2GB内存 16GB 玫瑰金",
               "小米 红米手机4X 全网通版 2GB内存 16GB 樱花粉"];

function $(id)
{
    return document.getElementById(id);
}
function clearAll()
{
    if(cart.products.length>0)
    {
        cart.products.splice(0,cart.products.length);
    }
    document.forms["myFrom"].reset();
}
function checkOut()
{
    cart.total = 0;
    cart.count=cart.products.length;
    for(let i=0;i<cart.count;i++)
    {
        cart.total +=cart.products[i].price
    }
    alert("您所选购的"+cart.count+"件，产品总价="+cart.total+"\n"+"请去支付！");
}
function checkSelect(ev)
{
    let x =ev.target;
    if(x.tagName == "INPUT"&&x.type == "checkbox")
    {
        let idx = x.name.substr(2);
        if (x.checked)
        {
            cart.products.push(products[idx]);
            cart.total +=products[idx].price;
            cart.count++;
        }
        else
        {
            cart.products.splice(cart.products.indexOf(products[idx],1));
            cart.total -=products[idx].price;
            cart.count--;
        }
    }
}
function shoppingCart()
{
    var selectList="";
    cart.products.forEach(function(product,i)
    {
        selectList +=(i+1)+"-"+product.name+",价值="+product.price+"\n";
    })
   
    var info = (cart.products.length==0)?"您的购物车为空，请选购！":selectList;
    alert(info);
}
