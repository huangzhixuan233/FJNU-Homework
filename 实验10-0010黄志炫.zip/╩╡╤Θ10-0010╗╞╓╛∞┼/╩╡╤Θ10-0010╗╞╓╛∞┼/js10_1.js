function $(id)
{
   return document.getElementById(id);
}
function checkcardno()
{
    var cno=myform.cardno.value;
    $("err_cardno").innerHTML="卡号不能为空或非数字开始的字符串！";
    if(cno == ""||isNaN(parseInt(cno)))
    {
        $("err_cardno").innerHTML="卡号不能为空！";
    }
    else if(cno.length!=10)
    {
        $("err_cardno").innerHTML="卡号长度必须为10！";
    }
    else
    {
        var firstnum = cno.charAt(0);
        if(firstnum=="0")
        {
            $("err_cardno").innerHTML="卡号不全为数字！";
        }
        else if (parseInt(cno).toString().length!=10)
        {
            $("err_cardno").innerHTML="卡号不全为数字";
            alert("卡号不全为数字");
        }
    }
}
function checkkey()
{
    var key1 = myform.key.value;
    $("err_key").innerHTML="";
    if(key1==""||key1 == null)
    {
        $("err_key").innerHTML="口令不能为空！";
    }
    else
    {
        if(key1.length<0||key1.length>15)
        {
            $("err_key").innerHTML="口令长度不能小于8或大于15！";
        }
    }
    function checkkey2()
    {
        var key21 = myform.key2.value;
        var key11=myform.key.value;
        $("err_key2").innerHTML="";
        if(key21==""||key21==null)
        {
            $("err_key2").innerHTML="口令不能为空";
        }
        else if(key21.length<0||key21.length>15)
        {
            $("err_key2").innerHTML="口令长度不能小于8或大于15";
        }
        else if(key21!=key11)
        {
            $("err_key2").innerHTML="口令与二次口令不相同！";
        }

    }
}