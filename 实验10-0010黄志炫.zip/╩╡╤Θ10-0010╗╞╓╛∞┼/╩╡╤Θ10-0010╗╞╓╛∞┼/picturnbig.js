function $(id)
{
    return document.getElementById(id);
}
$("smallbox").onmouseover = function()
{
    $("mask").style.display="block";
    $("bigbox").style.display="block";
};
$("smallbox").onmouseout=function()
{
    $("mask").style.display="none";
    $("bigbox").style.display="none";
};
$("smallbox").onmousemove = function(event)
{
    var event = event ||window.event;
    var pagex =event.pagex||event.clientX+document.documentElement.scrollLeft;
    var pagey =event.pagey||event.clientY+document.documentElement.scrollTop;
    var boxx=pagex-$("box").offsetLeft;
    var boxy=pagey-$("box").offsetTop;
    var maskx=boxx - $("mask").offsetWidth/2;
    var masky=boxy - $("mask").offsetHeight/2;
    if (maskx<0)
    {
        maskx=0;
    }
    if(maskx > $("smallbox").offsetWidth-$("mask").offsetWidth)
    {
        maskx =$("smallbox").offsetWidth-$("mask").offsetWidth;
    }
    if (masky<0)
    {
        masky=0;
    }
    if(masky > $("smallbox").offsetHeight-$("mask").offsetHeight)
    {
        masky =$("smallbox").offsetHeight-$("mask").offsetHeight;
    }
    $("mask").style.left =maskx+"px";
    $("mask").style.top =masky+"px";
    var bigImgToMove = $('bigimg').offsetWidth-$("bigbox").offsetWidth;
    var maskToMove = $('smallbox').offsetWidth-$("mask").offsetWidth;
    var rate = bigImgToMove/maskToMove;
    $("bigimg").style.marginLeft=-rate*maskx+"px";
    $("bigimg").style.marginTop = -rate*masky+"px";
};