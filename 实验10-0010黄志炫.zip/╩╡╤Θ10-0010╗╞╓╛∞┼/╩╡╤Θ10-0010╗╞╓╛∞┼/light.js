var lamp = {
    red: {
      obj: document.getElementById('red'),
      timeout: 30,
      style: ['red', 'gray', 'gray'],
      next: 'green'
    },
    yellow: {
      obj: document.getElementById('yellow'),
      timeout: 5,
      style: ['gray', 'yellow', 'gray'],
      next: 'red'
    },
    green: {
      obj: document.getElementById('green'),
      timeout: 35,
      style: ['gray', 'gray', 'green'],
      next: 'yellow'
    },
    gray:
    {
        obj:document.getElementById('gray'),
        style:['gray','gray','gray']
    },
    changeStyle(style) {
      this.red.obj.className = style[0];
      this.yellow.obj.className = style[1];
      this.green.obj.className = style[2];
    }
  };
  var count = {
        obj: document.getElementById('count'),
        change: function(num) {
          this.obj.innerHTML = (num < 10) ? ('0' + num) : num;
        }
      };
  var now = lamp.green;
  var timeout = now.timeout;
      lamp.changeStyle(now.style);
      count.change(timeout);
  setInterval(function() {
        if (--timeout <= 0) {
          now = lamp[now.next];
          timeout = now.timeout;
          lamp.changeStyle(now.style);
        }
        count.change(timeout);
        setInterval(function(){
            if(timeout== 5||timeout== 3||timeout== 1)
            {
                if(now==lamp.green||now==lamp.red)
                {
                    lamp.changeStyle(lamp.gray.style);
                }
            }
            else
            {
                lamp.changeStyle(now.style);
            }
        },500);

      }, 1000);